# IAP DB Auto Alert - Production Deployment Guide

## What this is
A self-monitoring system that checks 16 health/threshold items on your
4-node IAP RAC (`iap-db-dr`, `iap-db2-dr`, `iap-db3-dr`, `iap-db4-dr`)
every 30 minutes and sends ONE consolidated, color-coded HTML email per
run if anything breaches. Alert-only — no auto-remediation.

```
/home/oracle/scripts/
├── config/
│   ├── thresholds.yaml    <- edit thresholds/enable-disable checks here
│   ├── nodes.yaml         <- node list, instance names
│   └── exclusions.yaml    <- RMAN/batch-job exclusion patterns
├── bin/
│   ├── lib_collect.sh     <- shared collection engine (used by both schedules below)
│   ├── collect_health.sh  <- 30-min orchestrator: alerts ONLY on breach
│   ├── dbmon_wrapper.sh   <- cron entry point for the 30-min job (sources .oraenv)
│   ├── daily_summary.sh   <- 09:30/17:30 orchestrator: ALWAYS sends full status
│   ├── daily_summary_wrapper.sh <- cron entry point for the digest job (sources .oraenv)
│   ├── db_checks.sql      <- DB-wide checks (once, from Node1)
│   ├── dg_gap_standby.sql <- Data Guard standby-side sequence check
│   ├── os_node_check.sh   <- per-node OS checks (deployed to ALL 4 nodes)
│   ├── read_config.py     <- YAML -> shell variable helper
│   ├── alert_mailer.py    <- threshold evaluator + breach-only HTML mailer
│   └── daily_summary_mailer.py <- full status digest mailer (green/OK + breach detail)
├── state/                 <- suppression state + raw collection files (auto-created)
└── logs/                  <- daily run logs (auto-created)
```

**Two independent schedules, one shared collection engine (`lib_collect.sh`):**
- Every 30 min → `dbmon_wrapper.sh` → mail **only if something breaches** (with the 6-hour suppression rules already agreed)
- 09:30 & 17:30 daily → `daily_summary_wrapper.sh` → mail **always**, showing all 16 parameters — green "GOOD" rows for healthy ones, full color-coded detail for anything breached. No suppression logic applies to this digest; it's a snapshot, not an alert stream.

---

## STEP 1 — Prerequisites (all 4 nodes)

```bash
# Python 3 + PyYAML (RHEL 9 ships python3 by default)
sudo pip3 install pyyaml --break-system-packages

# Confirm sqlplus, crsctl, lsnrctl, chage are on PATH for the oracle/grid users
which sqlplus crsctl lsnrctl chage
```

## STEP 2 — Deploy the files

On the **orchestrator node** (Node1 = `iap-db-dr`), as the `oracle` user
(no `sudo`/root needed now that this lives under `/home/oracle`):

```bash
mkdir -p /home/oracle/scripts/{config,bin,state,logs}
# copy the extracted package contents:
cp -r config/* /home/oracle/scripts/config/
cp -r bin/*    /home/oracle/scripts/bin/
chmod +x /home/oracle/scripts/bin/*.sh
```

On **every node** (all 4, including Node1) — `os_node_check.sh` must exist
locally on each node because the orchestrator SSHes in and executes it there:

```bash
for NODE in iap-db-dr iap-db2-dr iap-db3-dr iap-db4-dr; do
  ssh oracle@$NODE "mkdir -p /home/oracle/scripts/bin"
  scp bin/os_node_check.sh oracle@$NODE:/home/oracle/scripts/bin/
  ssh oracle@$NODE "chmod +x /home/oracle/scripts/bin/os_node_check.sh"
done
```

## STEP 3 — Verify passwordless SSH (already in place per your confirmation)

From Node1, confirm all 4 nodes are reachable without a password prompt:

```bash
for NODE in iap-db-dr iap-db2-dr iap-db3-dr iap-db4-dr; do
  echo "== $NODE =="
  ssh -o BatchMode=yes -o ConnectTimeout=5 oracle@$NODE "hostname"
done
```
If any node prompts for a password, fix that node's SSH key trust before
proceeding — the script will otherwise silently report that node as
"SSH_CONNECTION_FAILED" every run.

## STEP 4 — Confirm your `.oraenv` SMTP variable names

Open `/root/.oraenv` and note the exact variable names it exports for:
SMTP host, port, username, password, mail-to, mail-cc.

Open `bin/alert_mailer.py` and check the `ENV_VAR_MAP` dictionary near the
top of the file — it already looks for common names (`SMTP_HOST`,
`MAIL_HOST`, `SMTP_USER`, `MAIL_TO`, etc.). **If your `.oraenv` uses
different variable names, add them to the appropriate list** in
`ENV_VAR_MAP`, e.g.:

```python
"host": ["SMTP_HOST", "MAIL_HOST", "SMTP_SERVER", "YOUR_ACTUAL_VAR_NAME"],
```

Quick test — after sourcing `.oraenv`, confirm the variables are visible:
```bash
source /root/.oraenv
env | grep -i -E "smtp|mail"
```

## STEP 5 — Site-specific edits required before go-live

These placeholders in the package MUST be adjusted to your environment:

| File | What to check |
|---|---|
| `config/thresholds.yaml` | `database.tns_alias` / `standby_tns_alias` — confirm these TNS aliases exist and resolve correctly from Node1 |
| `config/thresholds.yaml` | `db_listener_down.listener_name` — confirm actual listener name (`LISTENER_IAPDB` is a placeholder) |
| `config/exclusions.yaml` | Replace the placeholder `%BATCH_JOB%` / `%ETL%` module patterns with your real nightly batch job MODULE/ACTION names |
| `bin/collect_health.sh` | The Data Guard standby connect string (`sqlplus sys/@${DB_STANDBY_TNS_ALIAS} as sysdba`) — confirm remote SYSDBA connectivity to standby works with OS auth in your setup; if not, this block needs to run as a small SSH call to the DR host instead (structure is already there, just swap the connection method) |
| `bin/os_node_check.sh` | `DIAG_BASE` path assumes `$ORACLE_BASE/diag/rdbms/...` — confirm this matches your actual diag dest, or the `find` fallback will locate it (slightly slower) |

## STEP 6 — Dry run (no mail sent, inspect the collection file)

```bash
source /root/.oraenv
bash /home/oracle/scripts/bin/collect_health.sh
```
Then inspect:
```bash
cat /home/oracle/scripts/state/collect_*.dat     # raw check output
tail -50 /home/oracle/scripts/logs/dbmon_$(date +%Y%m%d).log
```
If no breaches exist, you'll see "No new (non-suppressed) breaches this
run - no mail sent." in the log — that's success, not a failure.

## STEP 7 — Force a test alert to confirm mail delivery end-to-end

Temporarily lower a threshold so something breaches on the next run, e.g.
in `thresholds.yaml`:
```yaml
cpu_usage:
  threshold_pct: 1        # will breach almost immediately
```
Run Step 6 again, confirm the email arrives and looks correct, then
**revert the threshold back to 65**.

## STEP 8 — Schedule via cron

As the `oracle` user (or root, if that's how DB jobs are run here):
```bash
crontab -e
```
Add BOTH entries:
```
# 30-min breach-only alerting
*/30 * * * * /bin/bash /home/oracle/scripts/bin/dbmon_wrapper.sh >> /home/oracle/scripts/logs/cron.log 2>&1

# Twice-daily full status digest - 09:30 and 17:30
30 9  * * * /bin/bash /home/oracle/scripts/bin/daily_summary_wrapper.sh >> /home/oracle/scripts/logs/cron_summary.log 2>&1
30 17 * * * /bin/bash /home/oracle/scripts/bin/daily_summary_wrapper.sh >> /home/oracle/scripts/logs/cron_summary.log 2>&1
```
The two jobs are independent — the digest never suppresses or is suppressed by the 30-min alert stream.

## STEP 9 — Post-deployment validation checklist

- [ ] Cron fires every 30 min (`grep dbmon /var/log/cron`)
- [ ] `/home/oracle/scripts/logs/dbmon_<date>.log` shows a fresh run each cycle
- [ ] Daily digest arrives at both 09:30 and 17:30 (`/home/oracle/scripts/logs/dbmon_summary_<date>.log`)
- [ ] Digest shows "ALL CLEAR" green banner when nothing is breaching (confirm on a clean run before testing a forced breach)
- [ ] All 4 nodes report OS checks (no persistent `SSH_CONNECTION_FAILED`)
- [ ] A deliberately-forced breach produces a correctly formatted email
- [ ] Item 9 (ORA errors) re-alerts every run while an error is present (by design)
- [ ] Other items do NOT re-alert within 6 hours of a prior alert for the same check+node
- [ ] `state/` and `logs/` directories aren't growing unbounded (housekeeping in `collect_health.sh` prunes >48h collection files and >30-day logs automatically)

## Customizing later (your requirement)

- **Change a threshold** → edit the value in `thresholds.yaml`, no restart needed (cron picks it up next run)
- **Disable a check** → set `enabled: false` under that check in `thresholds.yaml`
- **Add a batch job to the exclusion list** → add a pattern to `exclusions.yaml`
- **Add a new node** → add it to `nodes.yaml`, deploy `os_node_check.sh` to it, confirm passwordless SSH
- **Add a brand-new check (17th item)** → write an evaluator function in `alert_mailer.py` following the existing pattern, register it in the `EVALUATORS` dict, add its config block to `thresholds.yaml`, and add its data collection to `db_checks.sql` or `os_node_check.sh` as appropriate

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| No mail ever sent, even with real breaches | Check `ENV_VAR_MAP` in `alert_mailer.py` against actual `.oraenv` variable names |
| "SSH_CONNECTION_FAILED" for a node | Passwordless SSH broken for that node/user — test manually |
| Alert log check always empty | `DIAG_BASE` path wrong for your `ORACLE_SID` — check Step 5 |
| DG gap always 0 or wrong | Confirm standby connect string in `collect_health.sh` actually reaches the DR database |
| Same alert repeats every 30 min (other than item 9) | Check `/home/oracle/scripts/state/last_alert__*.json` — if `state/` is not writable, suppression can't persist |
